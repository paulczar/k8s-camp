## Intros

- Hello! We are:

   - .emoji[👨🏾‍🎓] Paul Czarkowski ([@pczarkowski](https://twitter.com/pczarkowski), VMware)
   - .emoji[👨🏾‍🎓] Tyler Britten ([@tybritten](https://twitter.com/tybritten), VMWare)


- Feel free to interrupt for questions at any time

- *Especially when you see full screen container pictures!*
