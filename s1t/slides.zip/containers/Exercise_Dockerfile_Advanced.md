# Exercise — writing better Dockerfiles

Let's update our Dockerfiles to leverage multi-stage builds!

The code is at: https://github.com/jpetazzo/wordsmith

Use a different tag for these images, so that we can compare their sizes.

What's the size difference between single-stage and multi-stage builds?
